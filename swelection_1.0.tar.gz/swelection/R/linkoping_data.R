#' @title Election result in Linköping
#' 
#' @description Election result in Linkoping per vote-area 2014
#' 
#' @format A \code{data frame} with with 20 columns, which are:
#' \describe{
#' The result for each of the nine biggest parties in Sweden in each vote-area in Linköping.
#' }
#' 
"linkoping_data2"